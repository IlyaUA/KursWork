#ifndef HELP_H
#define HELP_H

#include <QMainWindow>

namespace Ui
{
    class HelpWindow;
}

class help : public QMainWindow
{
    Q_OBJECT
public:
    //explicit help(QWidget *parent = nullptr);
    explicit help(QWidget *parent = 0);

signals:

public slots:

private:
    Ui::HelpWindow *ui;
};

#endif // HELP_H
