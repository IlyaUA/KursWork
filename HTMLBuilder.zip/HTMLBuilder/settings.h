#ifndef SETTINGS_H
#define SETTINGS_H

#include <QMainWindow>

namespace Ui
{
    class SettingsWindow;
}

class settings : public QMainWindow
{
    Q_OBJECT
public:
    explicit settings(QWidget *parent = nullptr);

signals:

public slots:

private slots:
    void on_radioButton_clicked();

    void on_radioButton_2_clicked();

private:
    Ui::SettingsWindow *ui;
};

#endif // SETTINGS_H
