#include "webviewmainwindow.h"
#include "ui_webviewmainwindow.h"
#include <QWebEngineView>
#include <mainwindow.h>

WebViewWindow::WebViewWindow(QWidget *parent) : QMainWindow(parent)
{
    ui->setupUi(this);

    QWebEngineView *a;
    a->load(QUrl("http://google.com/"));
}
