#include "webviewmainwindow.h"
#include "ui_webviewmainwindow.h"
#include <QWebEngineView>
#include <mainwindow.h>

WebViewMainWindow::WebViewMainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::WebViewMainWindow)
{
    ui->setupUi(this);

    QWebEngineView *a;
    a->load(QUrl("http://google.com/"));
}

WebViewMainWindow::~WebViewMainWindow()
{
    delete ui;
}
