#include "help.h"
#include "ui_helpwindow.h"
#include "ui_startmainwindow.h"
#include <mainwindow.h>
#include <filemanager.h>
#include "filemanager.h"
#include <QFile>
#include <QTextStream>

help::help(QWidget *parent) : QMainWindow(parent), ui(new Ui::HelpWindow)
{
    ui->setupUi(this);

    QString user = getenv("USER");
    QFile prefsLangFile("/Users/" + user + "/Desktop/HTMLBuilderLangPrefs.txt");
    prefsLangFile.open(QIODevice::ReadWrite | QIODevice::Text);
    QTextStream stream(&prefsLangFile);
    QString name = stream.readLine();
    if(name == "en")
    {
        ui -> label_2 -> setText("2017, Ilya Harebashvili, Ruslan Tereshchenko");
    }
    prefsLangFile.close();
}
