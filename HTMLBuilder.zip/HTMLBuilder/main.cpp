#include "mainwindow.h"
#include "filemanager.h"
#include <QApplication>

extern QString fileName;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    filemanager w;
    w.show();

    return a.exec();
}
