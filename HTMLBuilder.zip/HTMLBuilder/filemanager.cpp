#include "filemanager.h"
#include <help.h>
#include <settings.h>
#include "ui_startmainwindow.h"
#include "ui_helpwindow.h"
#include "ui_settingswindow.h"
#include <mainwindow.h>
#include "mainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QDesktopServices>
#include <QFileSystemModel>
#include <QMessageBox>

filemanager::filemanager(QWidget *parent) : QMainWindow(parent), ui(new Ui::StartWindow)
{
    ui->setupUi(this);

    QString user = getenv("USER");
    QFile prefsLangFile("/Users/" + user + "/Desktop/HTMLBuilderLangPrefs.txt");
    prefsLangFile.open(QIODevice::ReadWrite | QIODevice::Text);
    QTextStream langStream(&prefsLangFile);
    QString name = langStream.readLine();
    if(name == "ru")
    {
        ui -> pushButton -> setText("Создать репозиторий");
    }
    prefsLangFile.close();
}

void filemanager::file(QString code)
{
    QString user = getenv("USER");
    //
    QFile prefsFile("/Users/" + user + "/Desktop/HTMLBuilderPrefs.txt");
    prefsFile.open(QIODevice::ReadOnly | QIODevice::Text);
    QTextStream stream(&prefsFile);
    QString name = stream.readLine();
    prefsFile.close();
    //
    QFile file("/Users/" + user + "/Desktop/" + name + "/MyFile.html");
    file.open(QIODevice::WriteOnly);
    QTextStream Astream( &file);
    Astream << code << endl;
    file.close();
}

void filemanager::on_pushButton_clicked()
{
    QString user = getenv("USER");
    QString projectName = ui -> textEdit -> toPlainText();
    QFile prefsFile("/Users/" + user + "/Desktop/HTMLBuilderPrefs.txt");
    prefsFile.open(QIODevice::WriteOnly);
    QTextStream stream( &prefsFile);
    stream << projectName << endl;
    prefsFile.close();


    try
    {
        if(projectName.length() != 0)
        {
            QDir().mkdir("/Users/" + user + "/Desktop/" + projectName);
            QFile file("/Users/" + user + "/Desktop/" + projectName + "/MyFile.html");
            file.open(QIODevice::WriteOnly);
            file.close();

            MainWindow *w = new MainWindow;
            w->setAttribute(Qt::WA_DeleteOnClose);
            w->show();
        }
        else
        {
            throw std::exception();
        }
    }
    catch(...)
    {
        QMessageBox error;
        error.setText("Enter project's name");
        error.exec();
    }
}

void filemanager::on_pushButton_2_clicked()
{
    help *w = new help;
    w->setAttribute(Qt::WA_DeleteOnClose);
    w->show();
}

void filemanager::on_pushButton_3_clicked()
{
    settings *w = new settings;
    w->setAttribute(Qt::WA_DeleteOnClose);
    w->show();
}
