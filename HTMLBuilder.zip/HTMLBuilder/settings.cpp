#include "settings.h"
#include "ui_settingswindow.h"
#include "ui_startmainwindow.h"
#include <mainwindow.h>
#include <filemanager.h>
#include "filemanager.h"
#include <QFile>
#include <QTextStream>

settings::settings(QWidget *parent) : QMainWindow(parent), ui(new Ui::SettingsWindow)
{
    ui->setupUi(this);

    QString user = getenv("USER");
    QFile prefsLangFile("/Users/" + user + "/Desktop/HTMLBuilderLangPrefs.txt");
    prefsLangFile.open(QIODevice::ReadWrite | QIODevice::Text);
    QTextStream stream(&prefsLangFile);
    QString name = stream.readLine();
    if(name.length() < 1)
    {
        stream << "en" << endl;
    }
    else
    {
        if(name == "en")
        {
            ui -> radioButton->setChecked(true);
            ui -> groupBox -> setTitle("Language");
        }
        else if(name == "ru")
        {
            ui -> radioButton_2->setChecked(true);
            ui -> groupBox -> setTitle("Язык");
        }
    }
    prefsLangFile.close();
}

void settings::on_radioButton_clicked()
{
    QString user = getenv("USER");
    QFile prefsLangFile("/Users/" + user + "/Desktop/HTMLBuilderLangPrefs.txt");
    prefsLangFile.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream stream(&prefsLangFile);
    stream << "en" << endl;
    prefsLangFile.close();
    ui -> groupBox -> setTitle("Language");
}

void settings::on_radioButton_2_clicked()
{
    QString user = getenv("USER");
    QFile prefsLangFile("/Users/" + user + "/Desktop/HTMLBuilderLangPrefs.txt");
    prefsLangFile.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream stream(&prefsLangFile);
    stream << "ru" << endl;
    prefsLangFile.close();
    ui -> groupBox -> setTitle("Язык");
}
