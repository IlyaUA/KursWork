#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "ui_webviewwindow.h"
#include <QFile>
#include <QTextStream>
#include <QDesktopServices>
#include <QFileSystemModel>
#include <filemanager.h>
#include "filemanager.h"
#include <webview.h>
#include "webview.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //

    QString user = getenv("USER");
    QFile prefsLangFile("/Users/" + user + "/Desktop/HTMLBuilderLangPrefs.txt");
    prefsLangFile.open(QIODevice::ReadWrite | QIODevice::Text);
    QTextStream langStream(&prefsLangFile);
    QString langName = langStream.readLine();
    if(langName == "ru")
    {
        ui -> pushButton -> setText("Запустить");
    }
    prefsLangFile.close();

    filemanager object1;
    QFileSystemModel *model = new QFileSystemModel;
    QFile prefsFile("/Users/" + user + "/Desktop/HTMLBuilderPrefs.txt");
    prefsFile.open(QIODevice::ReadOnly | QIODevice::Text);
    QTextStream stream(&prefsFile);
    QString name = stream.readLine();
    prefsFile.close();
    model->setRootPath("/Users/" + user + "/Desktop/" + name + "/");
    ui -> treeView -> setModel(model);
    ui -> treeView -> setRootIndex(model->index("/Users/" + user + "/Desktop/" + name + "/"));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QString code = ui -> textEdit -> toPlainText();
    filemanager manager;
    manager.file(code);

    webview *s = new webview;
    s->show();
}
