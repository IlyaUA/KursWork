#ifndef WEBVIEW_H
#define WEBVIEW_H

#include <QMainWindow>

namespace Ui
{
    class WebViewWindow;
}

class webview : public QMainWindow
{
    Q_OBJECT
public:
    explicit webview(QWidget *parent = nullptr);

signals:

public slots:

private:
    Ui::WebViewWindow *ui;
};

#endif // WEBVIEW_H
