#ifndef WEBVIEWMAINWINDOW_H
#define WEBVIEWMAINWINDOW_H

#include <QMainWindow>

namespace Ui
{
    class WebViewMainWindow;
}

class WebViewMainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit WebViewMainWindow(QWidget *parent = 0);
    ~WebViewMainWindow();

private:
    Ui::WebViewMainWindow *ui;
};

#endif // WEBVIEWMAINWINDOW_H
