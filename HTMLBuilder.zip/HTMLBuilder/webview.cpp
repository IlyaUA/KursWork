#include "webview.h"
#include "ui_webviewwindow.h"
#include "ui_mainwindow.h"
#include <QWebEngineView>
#include <mainwindow.h>
#include "mainwindow.h"
#include <QGridLayout>
#include <QFile>

webview::webview(QWidget *parent) : QMainWindow(parent), ui(new Ui::WebViewWindow)
{
    ui->setupUi(this);
    windowTitle() = "Browser";
    QGridLayout *layout = new QGridLayout;
    QString user = getenv("USER");
    //
    QFile prefsFile("/Users/" + user + "/Desktop/HTMLBuilderPrefs.txt");
    prefsFile.open(QIODevice::ReadOnly | QIODevice::Text);
    QTextStream stream(&prefsFile);
    QString name = stream.readLine();
    prefsFile.close();
    //
    QWebEngineView *a = new QWebEngineView;
    a->load(QUrl("file:///Users/" + user + "/Desktop/" + name + "/MyFile.html"));

    layout->addWidget(a);

    QWidget * central = new QWidget();
    setCentralWidget(central);
    centralWidget()->setLayout(layout);
}
