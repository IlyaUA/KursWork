#ifndef FILEMANAGER_H
#define FILEMANAGER_H

#include <QMainWindow>

namespace Ui
{
    class StartWindow;
}

class filemanager : public QMainWindow
{
    Q_OBJECT
public:
    explicit filemanager(QWidget *parent = nullptr);

    void file(QString);

signals:

public slots:

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::StartWindow *ui;
};

#endif // FILEMANAGER_H
