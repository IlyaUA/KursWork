#ifndef WEBVIEWWINDOW_H
#define WEBVIEWWINDOW_H

#include <QMainWindow>

namespace Ui
{
    class WebViewWindow;
}

class WebViewWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit WebViewWindow(QWidget *parent = nullptr);

signals:

public slots:
    Ui::WebViewWindow *ui;
};

#endif // WEBVIEWWINDOW_H
